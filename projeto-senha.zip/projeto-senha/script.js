let sliderElement = document.querySelector("#slider");

let sizePassword = document.querySelector("#valor");
let password = document.querySelector("#password");

let containerPassword = document.querySelector("#container-password");

let minusculasElement = document.querySelector("#minusculas");
let maiusculasElement = document.querySelector("#maiusculas");
let numerosElement = document.querySelector("#numeros");
let especiaisElement = document.querySelector("#especiais");

let minusculas = 'abcdefghijklmnopqrstuvwxyz';
let maiusculas = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
let numeros = '0123456789';
let especiais = '!@#$%&*?';

let novaSenha = '';

sizePassword.innerHTML = sliderElement.value;

sliderElement.oninput = function(){
  sizePassword.innerHTML = this.value;
}

function generatePassword(){

  let charset = '';
  let pass = '';

  if(minusculasElement.checked){
    charset += minusculas;
  }

  if(maiusculasElement.checked){
    charset += maiusculas;
  }

  if(numerosElement.checked){
    charset += numeros;
  }

  if(especiaisElement.checked){
    charset += especiais;
  }

  if(charset == ''){
    alert("Selecione pelo menos uma opção!");
    return;
  }

  for(let i = 0; i < sliderElement.value; i++){

    let numeroAleatorio = Math.floor(Math.random() * charset.length);

    pass += charset.charAt(numeroAleatorio);
  }

  containerPassword.classList.remove("hide");

  password.innerHTML = pass;

  novaSenha = pass;
}

function copyPassword(){

  navigator.clipboard.writeText(novaSenha);

  alert("Senha copiada com sucesso!");
}

let nomeElement = document.querySelector("#nome");
let usuarioElement = document.querySelector("#usuario");
let containerUser = document.querySelector("#container-user");

let novoUsuario = '';

function generateUser(){

  let nome = nomeElement.value;

  if(nome == ''){
    alert("Digite um nome!");
    return;
  }

  let numero = Math.floor(Math.random() * 900) + 100;

  let usuario = nome.toLowerCase() + numero;

  usuario = usuario.replaceAll(" ", "");

  usuarioElement.innerHTML = usuario;

  containerUser.classList.remove("hide");

  novoUsuario = usuario;
}

function copyUser(){

  navigator.clipboard.writeText(novoUsuario);

  alert("Usuário copiado com sucesso!");
}