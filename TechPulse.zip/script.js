const form = document.querySelector("#login-form");
const email = document.querySelector("#email");
const senha = document.querySelector("#senha");
const mensagem = document.querySelector("#mensagem");

form.addEventListener("submit", function(event) {
  event.preventDefault();

  mensagem.classList.remove("erro", "sucesso");

  if (email.value.trim() === "" || senha.value.trim() === "") {
    mensagem.textContent = "Preencha o e-mail e a senha.";
    mensagem.classList.add("erro");
    return;
  }

  mensagem.textContent = "Login enviado com sucesso!";
  mensagem.classList.add("sucesso");
});
